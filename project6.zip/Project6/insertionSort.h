//Brayden Fuller, insertionSort.h, 3/29/21

#ifndef insertionSort_h
#define insertionSort_h

void insertionSort(int nums[], int N, int start, int increment);

#endif
