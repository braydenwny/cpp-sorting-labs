//Brayden Fuller, shellSort.h, 4/6/21

#ifndef shellSort_h
#define shellSort_h

//The shellSort from the txtbook
void shellSort(int nums[], int N);

//The modified one with 2 passes
void shellSortTwoPasses(int nums[], int N);

#endif
