//Brayden Fuller, quickSort.h, 4/25/21

#ifndef quickSort_h
#define quickSort_h

//Quicksort algorithm from pg 114 of txtbook, will call the first pivot list func
void quickSortOne(int nums[], int first, int last);

//nums[] is the list
//first is the beginning of the list 
//last is the end of the list


//Quicksort algorithim from pg 114, will call the second pivot list function
void quickSortTwo(int nums[], int first, int last);


//pivot list algorithm from page 116 of the book
int PivotListOne(int nums[], int first, int last);

//nums[] is the list
//first is the beginning of the list
//last is the end of the list


//pivot list algorithm from page 120 of the txtbook
int PivotListTwo(int nums[], int first, int last);

//nums[] iis the list
// first is the beginning of the list
//last is the end of the list

#endif
