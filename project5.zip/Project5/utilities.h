//Brayden Fuller, utilities.h, 3/29/21

#ifndef utilities_h
#define utilities_h

//Checks if list is sorted
bool CheckList(int nums[], int size);

//Checks if num1 is > num2
bool GreaterThan(int num1, int num2);

#endif
